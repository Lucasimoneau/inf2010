import java.util.ArrayList;
import java.util.List;

public class Main {
	
	public static void main(String[] args) {
		Graph g = new Graph();
		System.out.println("TP05 : Graphes");

		// Partie 1: A completer : Création du graphe

		List<Node> nodesList = new ArrayList<>();

		// All Nodes

		Node A = new Node(1, "A");
		Node B = new Node(2, "B");
		Node C = new Node(3, "C");
		Node D = new Node(4, "D");
		Node E = new Node(5, "E");
		Node F = new Node(6, "F");
		Node G = new Node(7, "G");

		nodesList.add(A);
		nodesList.add(B);
		nodesList.add(C);
		nodesList.add(D);
		nodesList.add(E);
		nodesList.add(F);
		nodesList.add(G);

		List<Edge> edgesList = new ArrayList<>();

		// Edges from A
		Edge A_B = new Edge(A,B,2);
		Edge A_C = new Edge(A,C,2);

		// Edges from B
		Edge B_A = new Edge(B,A,2);
		Edge B_C = new Edge(B,C,2);
		Edge B_D = new Edge(B,D,1);
		Edge B_E = new Edge(B,E,3);

		// Edges from C
		Edge C_A = new Edge(C,A,2);
		Edge C_B = new Edge(C,B,2);
		Edge C_D = new Edge(C,D,4);
		Edge C_E = new Edge(C,E,3);
		Edge C_F = new Edge(C,F,5);

		// Edges from D
		Edge D_B = new Edge(D,B,1);
		Edge D_C = new Edge(D,C,4);
		Edge D_F = new Edge(D,F,6);
		Edge D_G = new Edge(D,G,5);

		// Edges from E
		Edge E_B = new Edge(E,B,3);
		Edge E_C = new Edge(E,C,3);
		Edge E_F = new Edge(E,B,1);

		// Edges from F
		Edge F_C = new Edge(F,C,5);
		Edge F_D = new Edge(F,D,6);
		Edge F_E = new Edge(F,E,1);
		Edge F_G = new Edge(F,G,2);

		// Edges from G
		Edge G_D = new Edge(G,D,5);
		Edge G_F = new Edge(G,F,2);

		edgesList.add(A_B);
		edgesList.add(A_C);
		edgesList.add(B_A);
		edgesList.add(B_C);
		edgesList.add(B_D);
		edgesList.add(B_E);
		edgesList.add(C_A);
		edgesList.add(C_B);
		edgesList.add(C_D);
		edgesList.add(C_E);
		edgesList.add(C_F);
		edgesList.add(D_B);
		edgesList.add(D_C);
		edgesList.add(D_F);
		edgesList.add(D_G);
		edgesList.add(E_B);
		edgesList.add(E_C);
		edgesList.add(E_F);
		edgesList.add(F_C);
		edgesList.add(F_D);
		edgesList.add(F_E);
		edgesList.add(F_G);
		edgesList.add(G_D);
		edgesList.add(G_F);

		// Add Nodes and Edges

		g.setNodes(nodesList);
		g.setEdges(edgesList);
		
		// Partie 2: A completer : Implémentation de l’algorithme Dijkstra
		
		Dijkstra d = new Dijkstra(g);
		Node First = A;
		Node Last = G;
		d.findPath(First, Last);
		d.showTable();

		// Partie 3 : Afficher le chemin le plus court
		System.out.println(d.printShortPath(First, Last));
	
	}
}

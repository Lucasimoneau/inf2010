package tp1;

import java.util.Set;

public class Ellipse extends BaseShape {
    // TODO creer une ellipse avec une largeur et une longueur.

    public Ellipse(Double widthRadius, Double heightRadius) {

        double hauteurCarre = Math.pow(heightRadius,2);
        double largeurCarre = Math.pow(widthRadius,2);

        for(double i = -heightRadius ; i < heightRadius ; i+=0.1){

            double calculCoordX = Math.sqrt(largeurCarre*(1-(Math.pow(i,2)/hauteurCarre)));
            for(double j=-calculCoordX;j<calculCoordX;j++){

                add(new Point2d(j, i));
            }
        }
    }

    private Ellipse(Set<Point2d> coords) {
        super(coords);
    }

    // TODO appliquer la translation sur la forme.
    @Override
    public Ellipse translate(Point2d point) {
        return new Ellipse(translateAll(point));
    }

    // TODO appliquer la rotation sur la forme.
    @Override
    public Ellipse rotate(Double angle) {
        return new Ellipse(rotateAll(angle));
    }

    // TODO retourner une nouvelle forme.
    @Override
    public Ellipse clone() {
        return new Ellipse(getCoords());
    }
}

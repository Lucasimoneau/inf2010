package tp2;

public class LinkedHashMap<KeyType, DataType> {

    private static final double COMPRESSION_FACTOR = 2; // 50%
    private static final int DEFAULT_CAPACITY = 20;
    private static final int CAPACITY_INCREASE_FACTOR = 2;

    private Node<KeyType, DataType>[] map;
    private int capacity;
    private int size = 0;

    public LinkedHashMap() {
        capacity = DEFAULT_CAPACITY;
        map = new Node[DEFAULT_CAPACITY];
    }

    public LinkedHashMap(int capacity) {
        this.capacity = capacity;
        map = new Node[capacity];
    }

    /**
     * Finds the index attached to a particular key
     * @param key Value used to access to a particular instance of a DataType within map
     * @return The index value attached to a particular key
     */
    private int getIndex(KeyType key){
        int keyHash = key.hashCode() % capacity;
        return keyHash < 0 ? -keyHash : keyHash;
    }

    private boolean shouldRehash() {

        return size * COMPRESSION_FACTOR > capacity;
    }

    /** TODO
     * Increases capacity by CAPACITY_INCREASE_FACTOR (multiplication) and
     * reassigns all contained values within the new map
     */
    private void rehash() {
        int newCapacity = this.capacity * CAPACITY_INCREASE_FACTOR;

        Node<KeyType, DataType>[] oldMap = map;
        map = new Node[newCapacity];
        size = 0;
        for (int i = 0; i < oldMap.length; i++){
            if (oldMap[i] != null){
                Node<KeyType, DataType> nodeMap = oldMap[i];
                do {
                    put(nodeMap.key, nodeMap.data);
                    nodeMap = nodeMap.next;
                }
                while (nodeMap != null);
            }
        }
    }

    public int size(){
        return size;
    }

    public int getCapacity(){
        return capacity;
    }

    public boolean isEmpty(){
        return size == 0;
    }

    /** TODO
     * Finds if map contains a key
     * @param key Key which we want to know if exists within map
     * @return if key is already used in map
     */
    public boolean containsKey(KeyType key) {

        if(this.isEmpty()){
            return false;
        }
        int index = getIndex(key);
        return (this.map[index] != null);

    }
    /** TODO
     * Finds the value attached to a key
     * @param key Key which we want to have its value
     * @return DataType instance attached to key (null if not found)
     */
    public DataType get(KeyType key) {

        if(this.isEmpty()){
            return null;
        }
        Node<KeyType, DataType> nodeMap = map[getIndex(key)];
        if(nodeMap == null){
            return null;
        }
        do {
            if (nodeMap.key.equals(key)) {
                    return nodeMap.data;
            }
            nodeMap = nodeMap.next;
        }
        while(nodeMap != null);
            return null;
    }

    /** TODO
     * Assigns a value to a key
     * @param key Key which will have its value assigned or reassigned
     * @return Old DataType instance at key (null if none existed)
     */
    public DataType put(KeyType key, DataType value) {

        Node<KeyType, DataType> nodeMap = map[getIndex(key)];
        Node<KeyType, DataType> newNode = new Node(key, value);
        if(nodeMap == null){
            size++;
            if(shouldRehash()){
                rehash();
            }
            map[getIndex(key)] = newNode;
            return null;
        }
        else {
            nodeMap = map[getIndex(key)];
            Node<KeyType, DataType> oldNode = nodeMap;
            while(nodeMap != null){
                if(nodeMap.key.equals(key)){
                    DataType oldValue = nodeMap.data;
                    nodeMap.data = value;
                    return oldValue;
                }
                oldNode = nodeMap;
                nodeMap = nodeMap.next;
            }
            oldNode.next = newNode;
            return null;
        }
    }

    /** TODO
     * Removes the node attached to a key
     * @param key Key which is contained in the node to remove
     * @return Old DataType instance at key (null if none existed)
     */
    public DataType remove(KeyType key) {

        Node<KeyType, DataType> nodeMap = map[getIndex(key)];
        do {
            if(nodeMap == null){
                return null;
            }
            if (nodeMap.key.equals(key)) {
                DataType oldValue = nodeMap.data;
                map[getIndex(key)] =nodeMap.next;
                size--;
                return oldValue;
            }
            nodeMap = nodeMap.next;

        }
        while(nodeMap != null);
        return null;
    }


    /** TODO
     * Removes all nodes contained within the map
     */
    public void clear(){
        for( int i=0; i<this.getCapacity(); i++) {
            this.map[i] = null;
        }
    }


    static class Node<KeyType, DataType> {
        final KeyType key;
        DataType data;
        Node next; // Pointer to the next node within a Linked List

        Node(KeyType key, DataType data)
        {
            this.key = key;
            this.data = data;
            next = null;
        }
    }
}



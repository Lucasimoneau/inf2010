import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Stack;



public class Dijkstra {

    private Graph graph;
    private Map<Node, Edge> dijkstraTable[];
    private Map<Node, Integer> distancesTable;
    private Stack<Edge> path;
    private List<Node> nodePath;

	public Dijkstra (Graph g) {
		this.graph = g;
	}

	public void findPath(Node s, Node d) {
	    // A completer

        dijkstraTable = new HashMap[graph.getNodes().size()];
        nodePath = new ArrayList<Node>();
        path = new Stack<Edge>();
        distancesTable = new HashMap();

        for(int i = 0; i < graph.getNodes().size(); i++)
            dijkstraTable[i] = new HashMap();

        int Counter = 0;
        Boolean End = false;
        Node destination = d;
        Node start = s;
        distancesTable.put(start, 0);
        nodePath.add(start);

        while(End == false){
            Counter++;
            for(Node node : dijkstraTable[Counter-1].keySet()){
                dijkstraTable[Counter].put(node, dijkstraTable[Counter-1].get(node));
            }
            for(Node node : nodePath){
                for(Edge edge : graph.getEdgesGoingFrom(node)){
                    Node destinationNode = edge.getDestination();
                    if(nodePath.contains(destinationNode)== false){

                    if(distancesTable.get(destinationNode) != null){

                    if(edge.getDistance() + distancesTable.get(node) < distancesTable.get(destinationNode)){

                    dijkstraTable[Counter].remove(destinationNode);
                    distancesTable.remove(destinationNode);

                    dijkstraTable[Counter].put(destinationNode, edge);
                    distancesTable.put(destinationNode,distancesTable.get(node) + edge.getDistance());
                        }
                    }
                    else{
                        dijkstraTable[Counter].put(destinationNode, edge);
                        distancesTable.put(destinationNode,distancesTable.get(node) + edge.getDistance());
                    }
                    }
                }
            }
            Edge optimalEdge = null;
            for(Node node : distancesTable.keySet()){
                if(nodePath.contains(node) == false){
                    if(optimalEdge == null || distancesTable.get(node) < distancesTable.get(optimalEdge.getDestination()))
                        optimalEdge = dijkstraTable[Counter].get(node);
                }
            }
            nodePath.add(optimalEdge.getDestination());
            if(optimalEdge.getDestination()==destination)
                End = true;
        }
        Edge addEdge = null;
        while(destination != start){
            addEdge = dijkstraTable[Counter].get(destination);
            destination = addEdge.getSource();
            path.add(addEdge);
        }
	}

	private Node getMinimum(Map<Node, Edge> map) {
		Edge min = null;
		for (Node Key : map.keySet()) {
			if ( min == null || map.get(Key).getDistance() < min.getDistance()) {
				min = map.get(Key); 
			}
		}
		return min.getDestination();
	}

	private Edge getMinimum (Edge e1, Edge e2) {
		// A completer

        if(e1.getDistance() < e2.getDistance()) {
            return e1;
        }else {
            return e2;
        }
	}
	
	public String printShortPath(Node source, Node destination) {
		// A completer

        findPath(source, destination);
        int distance = 0;
        String display = "";

        for(Edge edge : path){
            distance = distance + edge.getDistance();
            display = edge.getDestination().getName() + " -> " + display;
        }
        String finalDisplay = "The shortest Path between " + source.getName()+" to "+destination.getName()+":\n" + source.getName()+" -> "+display.substring(0, display.length()-4)+" and has a distance of "+distance;
        return finalDisplay;
	}

	public void showTable() {
        // A completer

        List<Node> displayNodes = new ArrayList<Node>();
        System.out.print("Iteration" + '\t');
        for (Node node : graph.getNodes()) {
            System.out.print(node.getName() + '\t');
        }
        System.out.print('\n');
        System.out.print("\t\t" + 1 + "\t");
        for (Node node : graph.getNodes()){
            if (nodePath.get(0) == node)
                System.out.print(0 + node.getName() + '\t');
            else
                System.out.print("-\t");
        }
        System.out.print('\n');
        for(int j = 1; j <  nodePath.size() && j < graph.getNodes().size(); j++) {
            System.out.print("\t\t"+(j + 1) + "\t");
            for (Node node : graph.getNodes()) {
                if(dijkstraTable[j].get(node) == null)
                    System.out.print("-\t");
                else {
                    if(displayNodes.contains(node) == false){
                        System.out.print((distancesTable.get(dijkstraTable[j].get(node).getSource())+dijkstraTable[j].get(node).getDistance()) + dijkstraTable[j].get(node).getSource().getName() + '\t');
                        if (nodePath.get(j) == node)
                            displayNodes.add(node);
                    }
                    else
                        System.out.print("-\t");
                }
            }
            System.out.print('\n');
        }
        System.out.print('\n');
    }
}

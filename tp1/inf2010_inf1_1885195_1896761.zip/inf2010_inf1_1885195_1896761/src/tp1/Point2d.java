package tp1;

public class Point2d extends AbstractPoint {
    private final Integer X = 0;
    private final Integer Y = 1;

    // TODO creer un point en 2d avec 2 donnees
    public Point2d(Double x, Double y) {

        super(new Double[]{x, y});
    }

    // TODO creer un point a partir d'un vecteur de donnees
    public Point2d(Double[] vector) {

        super(new Double[]{vector[0], vector[1]});
    }

    public Double X() {
        return vector[X];
    }
    public Double Y() {
        return vector[Y];
    }

    // TODO prendre un vecteur de donnees et appliquer la translation.
    @Override
    public Point2d translate(Double[] translateVector) {

        Double[] newVector = new Double[2];
        newVector[0] = X() + translateVector[0];
        newVector[1] = Y() + translateVector[1];

        return new Point2d(newVector);
    }

    // TODO prendre un point et appliquer la translation.
    public Point2d translate(Point2d translateVector) {
        Double[] newVector = new Double[2];
        newVector[0] = X() + translateVector.X();
        newVector[1] = Y() + translateVector.Y();

        return new Point2d(newVector);
    }

    // TODO prendre un vecteur de donnees et appliquer la translation.
    @Override
    public Point2d rotate(Double[][] rotationMatrix) {

        Double[] newVecteur =new Double[2];

        newVecteur[0] = vector[0]* rotationMatrix[0][0]+ vector[1]*rotationMatrix[0][1];
        newVecteur[1] = vector[0]* rotationMatrix[1][0]+ vector[1]*rotationMatrix[1][1];

        return new Point2d(newVecteur);
    }

    // TODO prendre un angle de rotation, creer une matrice et appliquer la rotation.
    public Point2d rotate(Double angle) {

        Double[][] matriceRotation = new Double[2][2];
        matriceRotation[0][0] = Math.cos(angle);
        matriceRotation[0][1] = - Math.sin(angle);
        matriceRotation[1][0] = Math.sin(angle);
        matriceRotation[1][1] = Math.cos(angle);

       return rotate(matriceRotation);
    }

    // TODO prendre un facteur de division et l'appliquer.
    @Override
    public Point2d divide(Double divider) {

        Double[] vecteur =new Double[2];
        vecteur[0] = vector[0]/ divider;
        vecteur[1] = vector[1]/ divider;

        return new Point2d(vecteur);
    }

    // TODO prendre un facteur de multiplication et l'appliquer.
    @Override
    public Point2d multiply(Double multiplier) {

        Double[] vecteur =new Double[2];
        vecteur[0] = vector[0]* multiplier;
        vecteur[1] = vector[1]* multiplier;

        return new Point2d(vecteur);
    }

    // TODO prendre un facteur d'addition et l'appliquer.
    @Override
    public Point2d add(Double adder) {

        Double[] vecteur =new Double[2];
        vecteur[0] = vector[0] + adder;
        vecteur[1] = vector[1] + adder;

        return new Point2d(vecteur);
    }

    // TODO creer un nouveau point.
    @Override
    public Point2d clone() {

        Point2d point = new Point2d(X(), Y());
        return point;
    }
}

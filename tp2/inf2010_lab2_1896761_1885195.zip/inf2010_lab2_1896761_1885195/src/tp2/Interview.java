package tp2;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class Interview {
    /**
     * Finds all pairs within values which sum up to targetSum
     * @param values All possible values that can form a pair (can contain duplicates)
     * @param targetSum Pairs should add up to this
     * @return A collection containing all valid pairs with no permutations, but all combinations (empty collection if none found)
     */
    public Collection<MatchingPair> matchingPairs(Collection<Integer> values, Integer targetSum){

        ArrayList<MatchingPair> matchingPair = new ArrayList<MatchingPair>();
        Iterator<Integer> it1 = values.iterator();
        Iterator<Integer> it2;
        Integer v1, v2;
        while(it1.hasNext()){
            v1 = it1.next();
            it2 = values.iterator();
            while(it2.next() != v1){
            }
            while(it2.hasNext()){
                v2 = it2.next();
                int somme = v1 + v2;
                MatchingPair pair = new MatchingPair(v1, v2);
                if(somme == targetSum){
                        matchingPair.add(pair);
                }
            }
        }
        return (matchingPair);
    }
}


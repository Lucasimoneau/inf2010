package tp1;

import java.util.*;

public final class PointOperator {
    // TODO appliquer la translation sur le vecteur d'entree.
    public static Double[] translate(Double[] vector, Double[] translateVector) {

        for(int i =0; i<vector.length; i++){
            vector[i] += translateVector[i];
        }

        return vector;
    }

    // TODO appliquer la rotation sur le vecteur d'entree.
    public static Double[] rotate(Double[] vector, Double[][] rotationMatrix) {

        Double[] newVector = new Double[vector.length];
        for(int i = 0; i<vector.length; i++){
            newVector[i] = 0.0;
        }
        for(int i =0; i<rotationMatrix.length; i++){
            for(int j = 0; j<rotationMatrix[i].length; j++) {
                newVector[i] += vector[j] * rotationMatrix[i][j];
            }
        }
        return newVector;
    }

    // TODO appliquer le facteur de division sur le vecteur d'entree.
    public static Double[] divide(Double[] vector, Double divider) {

        for(int i = 0; i<vector.length; i++){

            vector[i]/= divider;
        }
        return vector;
    }

    // TODO appliquer le facteur de multiplication sur le vecteur d'entree.
    public static Double[] multiply(Double[] vector, Double multiplier) {
        for(int i = 0; i<vector.length; i++){

            vector[i]*= multiplier;
        }

        return vector;
    }

    // TODO appliquer le facteur d'addition sur le vecteur d'entree.
    public static Double[] add(Double[] vector, Double adder) {
        for(int i = 0; i<vector.length; i++){

            vector[i]+= adder;
        }

        return vector;
    }

    // TODO retourne la coordonnee avec les plus grandes valeurs en X et en Y.
    public static Point2d getMaxCoord(Collection<Point2d> coords) {

        if(coords.isEmpty()){
        return new Point2d(0.0,0.0);
        }
        Iterator<Point2d> iterator = coords.iterator();
        Double maxX = null;
        Double maxY = null;
        while(iterator.hasNext()){
            Point2d pointTemporaire = iterator.next();
            if(maxX==null && maxY==null){
                maxX= pointTemporaire.X();
                maxY= pointTemporaire.Y();
            }
            else{
                if(pointTemporaire.X()>maxX){
                    maxX = pointTemporaire.X();
                }
                if(pointTemporaire.Y()>maxY){
                    maxY = pointTemporaire.Y();
                }
            }
        }
        Point2d maxCoords = new Point2d(maxX, maxY);

        return (maxCoords);
    }

    // TODO retourne la coordonnee avec les plus petites valeurs en X et en Y.
    public static Point2d getMinCoord(Collection<Point2d> coords)
    {
        if(coords.isEmpty()){
            return new Point2d(0.0,0.0);
        }
        Iterator<Point2d> iterator = coords.iterator();
        Double minX = null;
        Double minY = null;
        while(iterator.hasNext()){
            Point2d pointTemporaire = iterator.next();
            if(minX==null && minY==null){
                minX= pointTemporaire.X();
                minY= pointTemporaire.Y();
            }
            else{
                if(pointTemporaire.X()<minX){
                    minX = pointTemporaire.X();
                }
                if(pointTemporaire.Y()<minY){
                    minY = pointTemporaire.Y();
                }
            }
        }
        Point2d minCoords = new Point2d(minX, minY);

        return (minCoords);
    }
}
